package com.github.unclecatmyself.common.constant;

/**
 * Created by MySelf on 2019/1/15.
 */
public class UtilConstant {

    public static final String PATH_PREFIX = "src/main/resources/";

    public static final String INSTANT = "TLS";

}

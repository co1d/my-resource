package com.github.unclecatmyself.auto;

/**
 * 自动配置厂
 * Create by UncleCatMySelf in 14:33 2019\1\5 0005
 */
public class AutoConfig {

    //地址配置，默认为空
    public static String address = "";

}

package com.github.unclecatmyself.common.bean.vo;

/**
 * Created by MySelf on 2019/1/2.
 */
public class SendServerVO {

    private String token;

    private String value;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

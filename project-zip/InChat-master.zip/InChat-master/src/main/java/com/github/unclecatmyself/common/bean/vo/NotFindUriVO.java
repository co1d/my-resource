package com.github.unclecatmyself.common.bean.vo;

/**
 * Create by UncleCatMySelf in 11:21 2018\12\31 0031
 */
public class NotFindUriVO {

    private String message;

    public NotFindUriVO(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

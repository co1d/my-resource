# 项目源码注解与说明



## auto

关于项目的启动配置

## bootstrap

项目核心的功能代码

## common

基础工具代码

### utils

- [HttpUtil](common/util/HttpUtil.md)
- [SslUtil](common/util/SslUtil.md)
- [SnowflakeIdWorker](common/util/SnowflakeIdWorker.md)
- [TokenGenerator](common/util/TokenGenerator.md)

## task

涉及数据管理
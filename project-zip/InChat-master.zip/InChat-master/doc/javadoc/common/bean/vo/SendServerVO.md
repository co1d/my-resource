## SendServerVO

包路径：com.github.unclecatmyself.common.bean.vo

类说明：服务通讯View Object

### 属性

- String token   

token标签

- String value

对应的值
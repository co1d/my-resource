## QQ群贡献建议

> 贡献者：小斑马

* 一个netty在物联网的应用，质量很高，有些模块可以直接拿来用
* https://github.com/cosmoplat-dev

* 可以考虑把长连接单独做成一个模块，上行下行数据可以直接放到消息队列里面去，上行数据上来后直接放到消息队列里，其他模块接收存数据库，长连接模块监听其他模块放到消息队列里的下发数据

> 贡献者：夜殇

* 加了规则引擎的物联网项目
* https://github.com/thingsboard/thingsboard

* 对上方项目的修改
* https://github.com/JaryZhen/rulegin

> 贡献者：[ELLIOT](https://github.com/chanjjaeseo)

* RabbitMQ 基本操作
* https://github.com/chanjjaeseo/rabbitMQ-sample

> 贡献者：[noseparte](https://github.com/noseparte)

* [netty4通信原理](../netty-study.md)
* MongoDB的基本操作
* https://github.com/noseparte/mongoTeam
